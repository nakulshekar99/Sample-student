package com.springboot;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Comparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.http.ResponseEntity;
@Component
public class Service {

@Autowired
private UserRepository repo;
public MessageResponse create(Student studentRequest)
{
	
	studentRequest.setId(studentRequest.getId());
	studentRequest.setName(studentRequest.getName());
	studentRequest.setMarks(studentRequest.getMarks());
	repo.save(studentRequest);
	return new MessageResponse("STudent created");
}
public Student update(Integer id,Student studentrequest)throws ResourceNotFoundException
{
      Optional<Student>student=repo.findById(id);
      if(student.isEmpty())
      {
    	  throw new ResourceNotFoundException("No such Student");
      }
      else
      {
    	Student obj = student.get();
    	obj.setName(studentrequest.getName());
    	 obj.setMarks(studentrequest.getMarks());
    	 
    	
    	  repo.save(obj);
      
	
	
	return obj;
      }
}
public Student single(Integer id)
{
	return repo.findById(id).get();
}
public List<Student> getAll()
{
	List<Student>list=repo.findAll();
	 list.sort(Comparator.comparing(Student::getName));
	 return list;
	
}


	
}
