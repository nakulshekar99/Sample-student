package com.springboot;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
@RestController
public class Controller {
@Autowired
private Service service;
@RequestMapping(method=RequestMethod.POST,value="/create")
public MessageResponse create(@RequestBody Student studentRequest)
{
	return service.create(studentRequest);
}
@RequestMapping(method=RequestMethod.GET,value="/all")
public ResponseEntity<List<Student>> getAllStudent()
{
	List<Student>students=service.getAll();
	return new ResponseEntity<>(students,HttpStatus.OK);
}
@RequestMapping(method=RequestMethod.GET,value="/find/{id}")
public ResponseEntity<Student>getStudentbyId(@PathVariable("id")Integer id)
{
	Student student= service.single(id);
	return new ResponseEntity<>(student,HttpStatus.OK);
}
@RequestMapping(method=RequestMethod.PUT,value="/update/{id}")
public Student update(@RequestBody Student studentrequest, @PathVariable("id")Integer id) throws  ResourceNotFoundException
{
	 
	 return service.update(id, studentrequest);
}
@RequestMapping(method=RequestMethod.GET,value="/single/{id}")
public Student single(@PathVariable Integer id)
{
	return service.single(id);
}

}
